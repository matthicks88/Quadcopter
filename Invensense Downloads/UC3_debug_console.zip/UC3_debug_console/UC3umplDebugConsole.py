#!/usr/bin/python
"""

UC3umplDebugConsole.py

Copyright 2011 InvenSense, Inc. All Rights Reserved.


"""
import serial, sys, os, time, string, pygame
from drawcube import *

class umplPacketReader:
    def __init__(self, port, quatdelegate=None, debugdelegate=None, caldelegate=None ):
        self.s = serial.Serial(port,115200)
        self.s.setTimeout(0.1)
        self.s.setWriteTimeout(0.2)
        try:
        # start: umpl application blocks waiting for getch() on boot
            self.s.write("\n") 
        except serial.serialutil.SerialTimeoutException:
            pass # write will timeout if umpl app is already started.
       
        if quatdelegate:
            self.quatdelegate = quatdelegate
        else:
            self.quatdelegate = emptyPacketDelegate()
            
        if debugdelegate:
            self.debugdelegate = debugdelegate
        else:
            self.debugdelegate = emptyPacketDelegate()
        
        if caldelegate:
            self.caldelegate = caldelegate
        else:
            self.caldelegate = emptyPacketDelegate()
       
        self.packets = []
        self.length = 0
        self.previous = None
    
    def read(self):
        NUM_BYTES = 14
        p = None
        while self.s.inWaiting() >= NUM_BYTES:
            rs = self.s.read(NUM_BYTES)
            if ord(rs[0]) == ord('$'):
                pktcode = ord(rs[1])
                if pktcode == 1:
                    d = debugPacket(rs)
                    self.debugdelegate.dispatch(d)
                elif pktcode == 2:
                    p = quatPacket(rs)
                    self.quatdelegate.dispatch(p) 
                elif pktcode == 3: # calibration request
                    c = calReqPacket.from_pkt(rs)
                    self.caldelegate.dispatch(c)
                elif pktcode == 4: # calibration start
                    c = calStartPacket.from_pkt(rs)
                    self.caldelegate.dispatch(c)
                elif pktcode == 5: # calibration data
                    c = calDataPacket.from_pkt(rs)
                    self.caldelegate.dispatch(c)
                elif pktcode == 6: # calibration stop
                    c = calStopPacket.from_pkt(rs)
                    self.caldelegate.dispatch(c)
                else:
                    print "no handler for pktcode",pktcode
            else:
                c = ' '
                print "serial misaligned!"
                while not ord(c) == ord('$'):
                    c = self.s.read(1)
                self.s.read(NUM_BYTES-1)
   
    def write(self,a):
        self.s.write(a)
    
    def close(self):
        self.s.close()
    
    def write_log(self,fname):
        f = open(fname,'w')
        for p in self.packets:
            f.write(p.logfile_line())
        f.close()

# ===========  PACKET DELEGATES  ==========

class packetDelegate(object):
    def loop(self,event):
        print "generic packetDelegate loop w/event",event
    def dispatch(self,p):
        print "generic packetDelegate dispatched",p

class emptyPacketDelegate(packetDelegate):
    def loop(self,event):
        pass
    def dispatch(self,p):
        pass

class cubePacketViewer (packetDelegate):
    def __init__(self):
        self.screen = Screen(480,400,scale=1.5)
        self.cube = Cube(30,60,10)
        self.q = Quaternion(1,0,0,0)
        self.previous = None  # previous quaternion
        self.latest = None    # latest packet (get in dispatch, use in loop)
        
    def loop(self,event):
        packet = self.latest
        if packet:
            q = packet.to_q().normalized()
            self.cube.erase(self.screen)
            self.cube.draw(self.screen,q)
            pygame.display.flip()
            self.latest = None

    def dispatch(self,p):
        if isinstance(p,quatPacket):
            self.latest = p
            
    def close(self):
        pass

class debugPacketViewer (packetDelegate):
    def loop(self,event):
        pass
    def dispatch(self,p):
        assert isinstance(p,debugPacket);
        p.display()


class cphState:
    waiting, send_len, send_data, expect_stop, rx_data , rx_stop = range(6) 

class calPacketHandler (packetDelegate):
    def __init__(self,fname):
        self.fname = fname
        
        self.state = cphState.waiting
        self.datapos = None
        self.expectlen = None
        self.data = None

    def debug_state(self):
        print "CAL HANDLER state",self.state,"datapos",self.datapos,"expectlen",self.expectlen,"len(data)",len(self.data)

    def loop(self,event):
        if self.state == cphState.waiting:
            # do nothing
            pass
        elif self.state == cphState.send_len:
            try:
                self.load_file(self.fname)
            except IOError: # file not found
                print ">>> could not find",self.fname,\
                        "aborting fetch calibration"
                p = calStopPacket(0)
                try:
                    self.send(p.to_pkt())
                except serial.serialutil.SerialTimeoutException:
                    self.error(p)
                else:
                    self.state = cphState.expect_stop 
            else:
                p = calStartPacket(self.expectlen)
                try:
                    self.send(p.to_pkt()) 
                except serial.serialutil.SerialTimeoutException:
                    self.error(p)
                else:
                    self.state = cphState.send_data
        elif self.state == cphState.send_data:
            p = calDataPacket(self.data[self.datapos:self.datapos+10])
            self.datapos += 10;
            try:
                self.send(p.to_pkt())
            except serial.serialutil.SerialTimeoutException:
                self.error(p)
            else:
                if self.datapos > self.expectlen:
                    self.state = cphState.expect_stop
            pass
        elif self.state == cphState.expect_stop:
            # do nothing
            pass
        elif self.state == cphState.rx_data:
            # do nothing
            pass
        elif self.state == cphState.rx_stop:
            # do nothing
            pass
        else:
            raise ValueError("calpacketHandler has invalid state", self.state)
        
    def dispatch(self,p):
        if self.state == cphState.waiting:
            if type(p) == calReqPacket:
                self.state = cphState.send_len
            elif type(p) == calStartPacket:
                # begin rx
                self.state = cphState.rx_data
                self.datapos   = 0
                self.expectlen = p.datalength
                self.data = []
            else:
                self.error(p)
        elif self.state == cphState.send_len:
            self.error(p)
        elif self.state == cphState.send_data:
            self.error(p)
        elif self.state == cphState.expect_stop:
            if type(p) == calStopPacket:
                if p.errcode == 0:
                    print ">>> successfully sent",self.expectlen,"bytes"
                    self.state = cphState.waiting
                else:
                    self.error(p)
            else:
                self.error(p)
        elif self.state == cphState.rx_data:
            if type(p) == calDataPacket:
                self.data += p.data
                self.datapos += 10
                if self.datapos >= self.expectlen:
                    self.state = cphState.rx_stop
            else:
                self.error(p)
        elif self.state == cphState.rx_stop:
            if type(p) == calStopPacket:
                self.save_file(self.fname)
                self.expectlen = None
                self.datapos = None
                self.data = None
                self.state = cphState.waiting
            else:
                self.error(p)
        else:
            raise ValueError("calpacketHandler has invalid state", self.state)
        pass
    
    def error(self,p):
        try:
            err = p.errcode
        except: 
            err = p
        print ">>> error! calPacketHandler in state", self.state, "got err", err
        self.state = cphState.waiting
    
    def save_file(self,fname):
        f = open(fname,'w')
        d = "".join(self.data)
        f.write(d[0:self.expectlen])
        f.close()
        print ">>> store calibration: saved",self.expectlen,"bytes to",fname

    def load_file(self,fname):
        f = open(fname,'r')
        d = f.read()
        f.close()
        self.data = list(d)
        self.datapos = 0
        self.expectlen = len(self.data)
        print ">>> fetch calibration: loaded",self.expectlen,"bytes from",fname
    
    def setSender(self,s):
        self.sender = s

    def send(self,p):
        assert isinstance(p,list)
        assert len(p) == 14
        def to_ch(a):
            if type(a) == str:
                return a
            elif type(a) == int:
                return chr(a)
            else: 
                raise ValueError("cant convert to char",a)
        
        chars = [ to_ch(m) for m in p ]
        assert ord(chars[0]) == ord('$')
        string = "".join(chars)
        self.sender.write(string)

# =============== PACKETS ================= 

# utility function:
def twoBytes(d1,d2):
    """ unmarshal two bytes into int16 """
    d = ord(d1)*256 + ord(d2)
    if d > 32767:
        d -= 65536
    return d

class debugPacket (object):
    """ body of packet is a debug string """
    def __init__(self,l):
        sss = []
        for c in l[2:12]:
            if ord(c) != 0:
                sss.append(c)
        self.s = "".join(sss)
    
    def display(self):
        sys.stdout.write(self.s)

 
class quatPacket (object):
    def __init__(self, l):
        """ list of 8 bytes expected."""
        self.l = l
        # each quat component is transmitted as a signed 16 byte int
        # fixed point where 1 = 2^14 LSB
        div = 1.0 / (1 << 14)
        self.q0 = twoBytes(l[2],l[3]) * div
        self.q1 = twoBytes(l[4],l[5]) * div
        self.q2 = twoBytes(l[6],l[7]) * div
        self.q3 = twoBytes(l[8],l[9]) * div

        # packet counter is 8 bit unsigned int
        self.counter = ord(l[11])
        
    def display_raw(self):
        l = self.l
        print "".join(
            [ str(ord(l[0])), " "] + \
            [ str(ord(l[1])), " "] + \
            [ str(ord(a)).ljust(4) for a in 
                                [ l[2], l[3], l[4], l[5], l[6], l[7], l[8], l[9], l[10] ] ] + \
            [ str(ord(a)).ljust(4) for a in 
                                [ l[8], l[9], l[10] , l[11], l[12], l[13]] ]
            )

        
    def display(self):
        if 1:
            print "qs " + " ".join([str(s).ljust(15) for s in
                [ self.q0, self.q1, self.q2, self.q3 ]])
        if 0:
            euler0, euler1, euler2 = self.to_q().get_euler()
            print "eulers " + " ".join([str(s).ljust(15) for s in
                [ euler0, euler1, euler2 ]])
        if 0:
            euler0, euler1, euler2 = self.to_q().get_euler()
            print "eulers " + " ".join([str(s).ljust(15) for s in
                [ (euler0 * 180.0 / 3.14159) - 90 ]])



    def to_q(self):
        return Quaternion(self.q0, self.q1, self.q2, self.q3)

# ============= CAL PACKETS ================

class calPacket (object):
    def to_pkt(self,data):
        assert len(data) == 10
        return [ '$'
               , self.idx
               , data
               , '\r\n']
        

class calReqPacket (object):
    def __init__(self):
        self.idx = 3
        pass
    @classmethod
    def from_pkt(cls,rs):
        assert ord(rs[1]) == 3
        return cls()

class calStartPacket (object):
    def __init__(self,datalength):
        assert isinstance(datalength,int)
        assert datalength > 0
        assert datalength < 65535
        self.idx = 4
        self.datalength = datalength


    def to_pkt(self):
        data = [0] * 10
        data[0] = int(self.datalength / 256)
        data[1] = self.datalength % 256
        pkt =  [ '$', self.idx ] + data + [ '\r', '\n']
        return pkt

    @classmethod
    def from_pkt(cls,rs):
        assert ord(rs[1]) == 4
        datalength = twoBytes(rs[2],rs[3])
        return cls(datalength)

class calDataPacket (object):
    def __init__(self,data):
        self.idx = 5
        if len(data) < 10: # add padding
            data += [0] * (10 - len(data))
        self.data = data

    def to_pkt(self):
        pkt =  [ '$', self.idx ] + self.data + [ '\r', '\n']
        return pkt

    @classmethod
    def from_pkt(cls,rs):
        assert ord(rs[1]) == 5
        data = rs[2:12]
        return cls(data)

class calStopPacket (object):
    def __init__(self,errcode):
        self.idx = 6
        self.errcode = errcode
    
    def to_pkt(self):
        data = [0] * 10
        data[0] = self.errcode
        data[1] = self.errcode
        pkt =  [ '$', self.idx ] + data + [ '\r', '\n']
        return pkt
    
    @classmethod
    def from_pkt(cls,rs):
        assert ord(rs[1]) == 6
        if rs[2] == rs[3]:
            errcode = ord(rs[2]) 
        else:
            errcode = None
        return cls(errcode)


# =============== MAIN ======================

if __name__ == "__main__":
    if len(sys.argv) == 2:
        comport = int(sys.argv[1]) - 1
    else:
        print "usage: " + os.path.basename(sys.argv[0]) + " port"
        sys.exit(-1)


    pygame.init()
    viewer = cubePacketViewer()
    debug  = debugPacketViewer()
    cal    = calPacketHandler("calibdata")

    reader = umplPacketReader(comport, 
                quatdelegate = viewer, 
                debugdelegate = debug, 
                caldelegate = cal)
    cal.setSender( reader )

    while 1:
        event = pygame.event.poll()
        if event.type == pygame.QUIT \
            or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                viewer.close()
                break
        
        reader.read()
        viewer.loop(event)
        debug.loop(event)
        cal.loop(event)

        pygame.time.delay(0) # if system load is too high, increase this 'sleep' time.

