/**
 * \file
 *
 * \brief SENSORS_XPLAINED_BOARD board header file.
 *
 * This file contains definitions and services related to the features of the
 * SENSORS_XPLAINED_XXX Xplained boards.
 *
 * To use these boards, define EXT_BOARD=SENSORS_XPLAINED_XXX, where \c 'XXX'
 * is a place holder for the specific sensor extension board as defined in
 * the board.h file.  For example, SENSORS_XPLAINED_INERTIAL_1 selects a
 * configuration supporting the Atmel Inertial Sensor Board #1.
 *
 * When this header file is included in a platform build, the
 * \c SENSORS_XPLAINED_BOARD configuration constant will be defined so
 * that conditionally built pieces of platform functionality can be invoked
 * to make the sensor board usable to the system.  For example, the
 * platform board_init() routine can conditionally compile calls to
 * sensor_board_init().
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */


#ifndef _sensors_xplained_h_
#define _sensors_xplained_h_


//! \internal Atmel Xplained Development Board Configuration

#include "conf_board.h"
#include "xplained_headers.h"


#ifdef __cplusplus
extern "C" {
#endif



//! \name Sensor Board Configuration Constants
// @{

#define SENSORS_XPLAINED_BOARD

#if (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_1)
//! \name ATAVRSBIN1 Inertial Board Configuration
#   define CONF_SENSOR_BUS_TWI      //!< Configure TWI bus interface
#   define INCLUDE_AK8975           //!< AKM 3-axis electronic compass
#   define INCLUDE_BMA150           //!< Bosch 3-axis accelerometer
#   define INCLUDE_ITG3200          //!< InvenSense 3-axis gyroscope
#elif (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_2)
//! \name ATAVRSBIN2 Inertial Board Configuration
#   define CONF_SENSOR_BUS_TWI      //!< Configure TWI bus interface
#   define INCLUDE_HMC5883L         //!< Honeywell 3-axis magnetometer
#   define INCLUDE_IMU3000          //!< InvenSense 3-axis gyroscope
#   define INCLUDE_KXTF9            //!< Kionix 3-axis accelerometer
#elif (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_A1)
//! \name ATAVRSBINA1 Inertial Board Configuration
#   define CONF_SENSOR_BUS_TWI      //!< Configure TWI bus interface
#   define INCLUDE_AK8975           //!< AKM 3-axis electronic compass
#   define INCLUDE_IMU3000          //!< InvenSense 3-axis gyroscope
#   define INCLUDE_KXTF9            //!< Kionix 3-axis accelerometer
#elif (EXT_BOARD == SENSORS_XPLAINED_PRESSURE_1)
//! \name ATAVRSBPR1 Barometric Pressure Board Configuration
#   define CONF_SENSOR_BUS_TWI      //!< Configure TWI bus interface
#   define INCLUDE_BMP085           //!< Bosch barometric pressure sensor
#elif (EXT_BOARD == SENSORS_XPLAINED_LIGHT_1)
//! \name ATAVRSBLP1 Light / Proximity Board Configuration
#   define CONF_SENSOR_BUS_TWI      //!< Configure TWI bus interface
#   define INCLUDE_SFH4650          //!< Osram infrared emitter
#endif

// @}


/*! \name Xplained Board J1 Connector Pin Mapping
 *
 * These constants map AVR & AVR32 ports to pins on the Xplained board J1
 * connector where pins on the 10-pin header correspond to the following
 * functions:
 *
 * \verbatim
 *
 *      10-pin Header           Function
 *  -------------------------------------------
 *      Pin 1                   SDA
 *      Pin 2                   SCL
 *      Pin 3                   RXD
 *      Pin 4                   TXD
 *      Pin 5                   SS
 *      Pin 6                   MOSI
 *      Pin 7                   MISO
 *      Pin 8                   SCK
 *
 * \endverbatim
 */
#define SENSOR_BOARD_PIN1       XPLD_HEADER_J1_PIN1
#define SENSOR_BOARD_PIN2       XPLD_HEADER_J1_PIN2
#define SENSOR_BOARD_PIN3       XPLD_HEADER_J1_PIN3
#define SENSOR_BOARD_PIN4       XPLD_HEADER_J1_PIN4
#define SENSOR_BOARD_PIN5       XPLD_HEADER_J1_PIN5
#define SENSOR_BOARD_PIN6       XPLD_HEADER_J1_PIN6
#define SENSOR_BOARD_PIN7       XPLD_HEADER_J1_PIN7
#define SENSOR_BOARD_PIN8       XPLD_HEADER_J1_PIN8


#if UC3
#   define SENSOR_PIN1_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN1 / 8))
#   define SENSOR_PIN2_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN2 / 8))
#   define SENSOR_PIN3_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN3 / 8))
#   define SENSOR_PIN4_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN4 / 8))
#   define SENSOR_PIN5_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN5 / 8))
#   define SENSOR_PIN6_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN6 / 8))
#   define SENSOR_PIN7_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN7 / 8))
#   define SENSOR_PIN8_IRQ      (AVR32_GPIO_IRQ_0 + (SENSOR_BOARD_PIN8 / 8))
#endif


/*! \name MEMS Sensor I/O Pins
 *
 * The following constants specify I/O expansion header pins that are used as
 * sensor event signal inputs to the MCU and, in some cases, control signal
 * outputs from the MCU to the MEMS sensor device.  For example, the \c BMP085
 * pressure sensor on the \ref ATAVRSBPR1 board provides a pressure sample
 * End-of-Conversion (EOC) input signal to the MCU and a device "master clear"
 * and reset signal (XCLR) output from the MCU to the sensor.
 *
 * These definitions are provided as a board-level description for the MEMS
 * sensor drivers and are not used directly in sensor service client
 * applications.
 */
#define INVALID_PIN_NUMBER      ((uint32_t) -1)

#if (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_1)
#   define ak8975_sigint        (SENSOR_BOARD_PIN3)
#   define bma150_sigint        (SENSOR_BOARD_PIN4)
#   define itg3200_sigint       (SENSOR_BOARD_PIN5)
#   define ak8975_sigout        (INVALID_PIN_NUMBER)
#   define bma150_sigout        (INVALID_PIN_NUMBER)
#   define itg3200_sigout       (INVALID_PIN_NUMBER)
#elif (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_2)
#   define hmc5883l_sigint      (SENSOR_BOARD_PIN3)
#   define kxtf9_sigint         (SENSOR_BOARD_PIN4)
#   define imu3000_sigint       (SENSOR_BOARD_PIN5)
#   define hmc5883l_sigout      (INVALID_PIN_NUMBER)
#   define kxtf9_sigout         (INVALID_PIN_NUMBER)
#   define imu3000_sigout       (INVALID_PIN_NUMBER)
#elif (EXT_BOARD == SENSORS_XPLAINED_INERTIAL_A1)
#   define ak8975_sigint        (SENSOR_BOARD_PIN3)
#   define kxtf9_sigint         (SENSOR_BOARD_PIN4)
#   define imu3000_sigint       (SENSOR_BOARD_PIN5)
#   define ak8975_sigout        (INVALID_PIN_NUMBER)
#   define kxtf9_sigout         (INVALID_PIN_NUMBER)
#   define imu3000_sigout       (INVALID_PIN_NUMBER)
#elif (EXT_BOARD == SENSORS_XPLAINED_PRESSURE_1)
#   define bmp085_sigint        (SENSOR_BOARD_PIN4)
#   define bmp085_sigout        (SENSOR_BOARD_PIN3)
#elif (EXT_BOARD == SENSORS_XPLAINED_LIGHT_1)
#   define sfh4650_sigint       (SENSOR_BOARD_PIN3)
#   define sfh4650_sigout       (INVALID_PIN_NUMBER)
#endif


//! \name GPIO Pin Interrupt Handler Callback Type

typedef void (* GPIO_IRQ_HANDLER)(volatile void *);


/*! \brief These functions initialize Xplained sensor board resources
 *
 * sensor_board_init() should be called to ensure proper initialization
 * of sensor extension board hardware connected to an "Xplained"
 * development platform.
 */
extern void sensor_board_init (void);
extern bool sensor_board_irq_connect (uint32_t, GPIO_IRQ_HANDLER, void *);



#ifdef __cplusplus
}
#endif

#endif /* _sensors_xplained_h_ */
