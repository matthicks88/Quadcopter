/*
 * testFunctions.h
 *
 * Created: 7/15/2011 2:17:47 PM
 *  Author: sgurumani
 */ 


#ifndef TESTFUNCTIONS_H_
#define TESTFUNCTIONS_H_


void testLowPowerState(void);


#endif /* TESTFUNCTIONS_H_ */