/*
 * testFunctions.c
 *
 * Created: 7/15/2011 2:11:30 PM
 *  Author: sgurumani
 */ 

#include "ml.h"
#include "mldl_cfg.h"
#include "mpu.h"
#include "mldl_cfg.h"
#include "log.h"
#include "mldl.h"

#undef MPL_LOG_TAG
#define MPL_LOG_TAG "MPL-test"
void testLowPowerState(void)
{
    unsigned char b;
    struct mldl_cfg *mldl_cfg = inv_get_dl_config();
    inv_serial_read(inv_get_serial_handle(), mldl_cfg->mpu_chip_info->addr,
                    MPUREG_PWR_MGMT_1, 1, &b);
    MPL_LOGD("MPUREG_PWR_MGMT_1= %d\n", b);
    inv_serial_read(inv_get_serial_handle(), mldl_cfg->mpu_chip_info->addr,
                    MPUREG_PWR_MGMT_2, 1, &b);
    MPL_LOGD("MPUREG_PWR_MGMT_2= %d\n", b);
    inv_serial_read(inv_get_serial_handle(), mldl_cfg->mpu_chip_info->addr,
                    MPUREG_ACCEL_MOT_DUR, 1, &b);
    MPL_LOGD("MPUREG_ACCEL_MOT_DUR= %d\n", b);
    struct ext_slave_config config;
    long data;
    config.key = MPU_SLAVE_CONFIG_ODR_RESUME;
    config.len = sizeof(long);
    config.data = &data;
    inv_mpu_get_accel_config(mldl_cfg,
                             inv_get_serial_handle(),
                             inv_get_serial_handle(), &config);
    MPL_LOGI("Actual ODR: %ld mHz\n", data);
}