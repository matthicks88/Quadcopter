/*
 $License:
    Copyright (C) 2011 InvenSense Corporation, All Rights Reserved.
 $
 */

#ifndef INVENSENSE_INV_KEY_0_96_H__
#define INVENSENSE_INV_KEY_0_96_H__

#include "mltypes.h"
#include "mlinclude.h"
#include "ml.h"

inv_error_t inv_key_0_96(struct inv_obj_t *inv_obj);

#endif // INVENSENSE_INV_KEY_0_96_H__


