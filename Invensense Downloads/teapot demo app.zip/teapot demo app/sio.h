#ifndef _SIO_H
#define _SIO_H

#include "ctypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /* ------------ */
    /* - Defines. - */
    /* ------------ */

    /* - Error Codes. - */

#define SIO_SUCCESS 0
#define SIO_ERROR   1

    /* ---------- */
    /* - Enums. - */
    /* ---------- */

    /* --------------- */
    /* - Structures. - */
    /* --------------- */

#define SIO_RBUFF_MAX    4096
#define SIO_RBUFF_SIZE    14

    //#define SIO_RBUFF_DYNAMIC  1
#define SIO_RBUFF_DYNAMIC  0

#define PROCESS_BUFFER_ON_COMMAND	0x0000
#define AUTO_PROCESS_BUFFER			0x0001

typedef struct
{

    U16 port;
    U32 baud;

    HANDLE sioHndl;
    HANDLE hDevice; // handle to the drive to be examined

    U8 readBuffer[128];
    U8 writeBuffer[128];

    U16 rBuffRIndex;
    U16 rBuffWIndex;
#if !SIO_RBUFF_DYNAMIC
    U8 rBuff[SIO_RBUFF_MAX][SIO_RBUFF_SIZE];
#else
    U8 *rBuff;
#endif
    U16 rBuffMax;
    U16 rBuffNumBytes;

    U8 runThread;
    U8 autoProcess;

} SIO_Vars_t;

/* --------------------- */
/* - Function p-types. - */
/* --------------------- */
unsigned short SIOSetCom(unsigned short nPort, unsigned int dwBaud);
int SIOInit(int nPort, DWORD dwBaud);
unsigned long SIOUartGetQStatus(void);

int SIOOpen(unsigned char autoProcess, unsigned char createThread);
int SIOClose(void);
int SIODeviceIoControl(void);
int SIORead(void);
int SIOWrite(void);
int SIOSetBufferSize(unsigned short bufferSize);
int SIOBufferUpdate(void);
int SIOHandler(void);
int SIOReadBuffer(unsigned short cnt, unsigned char bufferMode,
                  unsigned char *rBuff);
int SIOEmptyBuffer(void);
int SIOPktsInBuffer(unsigned short *pktsInBuffer);
int SIOCreateMutex(void);
int SIOLockMutex(void);
int SIOUnlockMutex(void);


#ifdef __cplusplus
}
#endif

#endif /* _TEMPLATE_H */
